# ng-training-ajax
ajax examples
