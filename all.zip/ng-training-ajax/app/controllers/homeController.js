(function(){
	angular
	  	.module("synechronModule")
	  	.controller("homeController", function($scope){
	  		$scope.compName = "Synechron";
	  		$scope.branch = "Bangalore";
	  	});
})()
