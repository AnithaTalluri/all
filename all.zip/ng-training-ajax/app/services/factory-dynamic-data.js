angular
.module("synechronModule")
.factory("dynamicFactory", function($http){
	// var getHeroAjax = $http.get("data/heroes.json");
	var getHeroAjax = $http.get("http://localhost:1234/giveheros");
	return {
		hd : getHeroAjax
	};
});
