(function(){
	angular
  	.module("synechronModule", ["ngRoute"]);
}())
