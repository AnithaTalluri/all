# ng-training
Synechron Bangalore AngularJS Training
