angular.module("app").controller("homecontroller", function($scope){
	$scope.companyName = "Synechron";
	$scope.branch = "Bangalore";
});
