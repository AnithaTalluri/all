angular
.module("app")
.controller("herocontroller", function($scope){
	
	$scope.heros = [
        {title : 'Batman',   photo:'images/batman.jpg',    power:7,    price : 123.45678, releaseDate : '2015-11-28', city : 'Gothem'},
        {title : 'Superman', photo:'images/superman.jpg',  power:9,    price : 222.67458, releaseDate : '2015-11-29', city : 'Manhatten'},
        {title : 'Ironman',  photo:'images/ironman.jpg',   power:8,    price : 163.76458, releaseDate : '2015-11-30', city : 'New York'},
        {title : 'Spiderman', photo:'images/spiderman.jpg', power:6,   price : 233.56478, releaseDate : '2015-12-01', city : 'New York'},
        {title : 'Phantom',  photo:'images/phantom.jpg',   power:7,    price : 453.45678, releaseDate : '2015-12-02', city : 'Bangala'}
        ];
        
    $scope.prop = 'title';
    $scope.message = 'message from controller';
    $scope.rev = false;
    
    $scope.sortMe = function(){
    	$scope.prop = arguments[0]; 
    	$scope.rev = !$scope.rev;
    };
    
});