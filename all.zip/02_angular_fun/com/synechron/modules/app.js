angular.module("app",["ngRoute"]).config(function($routeProvider){
	var url = [
	"<div class='jumbotron'><h1> {{companyName}} </h1> <h3>{{branch}}</h3> <a href='#/heros' class='btn btn-primary'>Show Heros</a> </div>",
	"com/synechron/views/herosView.html",
	];
	
	$routeProvider
	.when("/", {
		template : url[0],
		controller : "homecontroller"
	})
	.when("/heros", {
		templateUrl : url[1],
		controller : "herocontroller"
	})
});
