angular
  	.module("synechronModule", ["ngRoute"]);