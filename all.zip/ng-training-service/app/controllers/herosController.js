angular
	  	.module("synechronModule")
	  //	.controller("synechronController", function($scope,staticFactory){
	  	.controller("synechronController", function($scope,staticService){
	  		$scope.heros = staticService.getData();
			$scope.prop = 'title';
			$scope.rev = false;
			$scope.fil = '';
			$scope.sortMe = function(field){
				$scope.prop = field;
				$scope.rev = !$scope.rev;
			}
	  	});