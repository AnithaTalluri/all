angular
	  	.module("synechronModule")
	  //	.controller("moviesController", function($scope, $routeParams, staticFactory){
	  	.controller("moviesController", function($scope, $routeParams, staticService){
	  		$scope.heroid = $routeParams.id;
	  		$scope.moviesList = [];
	  		
	  		var getMovies = function(val){
	  			// for( hero in $scope.heros ){
	  			for(var i = 0; i < $scope.heros.length ; i++){
	  				if($scope.heros[i].id == val){
	  					$scope.moviesList = $scope.heros[i].movieslist;
	  				}
	  			}
	  		};

	  		$scope.heros = staticService.getData();
					
			getMovies($scope.heroid);
			
			$scope.prop = 'title';
			$scope.rev = false;
			$scope.fil = '';
			$scope.sortMe = function(field){
				$scope.prop = field;
				$scope.rev = !$scope.rev;
			}
	  	});