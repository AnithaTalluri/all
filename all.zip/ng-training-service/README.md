# ng-training-service
steps of service example
